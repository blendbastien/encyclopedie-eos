/* Encyclopédie d'Éos · v1.0.0
 * Un article = un journal Foundry (droits, partage, liens @UUID, compendiums restent natifs).
 *  - ses champs (catégorie, gabarit, monde, étiquettes, fiche, relations, saga, année) : flags « encyclopedie-eos » ;
 *  - ses sections : ses pages (texte ou image), éditées avec l'éditeur de Foundry, secrètes page par page.
 * Révélation : Secret (aucun droit) → Connu de nom (limité : titre, image, résumé) → Révélé (observateur).
 * Fenêtre « Encyclopédie » : accueil, catégories, sagas, chronologie, A–Z, recherche, cinq gabarits.
 */
const ID = 'encyclopedie-eos';
const OWN = CONST.DOCUMENT_OWNERSHIP_LEVELS;

const CATS = {
  personnage: { label: 'Personnages', one: 'Personnage', icon: 'fa-user-crown', tpl: 'fiche', fields: [['titre', 'Titre ou rôle'], ['espece', 'Peuple'], ['statut', 'Statut', 'select', ['Vivant', 'Mort', 'Disparu', 'Inconnu']], ['age', 'Âge'], ['origine', 'Origine'], ['citation', 'Citation', 'textarea']] },
  lieu: { label: 'Lieux', one: 'Lieu', icon: 'fa-castle', tpl: 'fiche', fields: [['nature', 'Nature', 'select', ['Royaume', 'Région', 'Cité', 'Village', 'Forteresse', 'Donjon', 'Ruines', 'Site naturel', 'Bâtiment', 'Autre']], ['population', 'Population'], ['gouvernance', 'Gouvernance'], ['climat', 'Climat'], ['ressources', 'Ressources']] },
  faction: { label: 'Factions', one: 'Faction', icon: 'fa-flag', tpl: 'fiche', fields: [['nature', 'Nature', 'select', ['Royaume', 'Ordre', 'Guilde', 'Culte', 'Clan', 'Compagnie', 'Société secrète', 'Autre']], ['devise', 'Devise'], ['effectif', 'Effectif'], ['reputation', 'Réputation'], ['embleme', 'Emblème']] },
  peuple: { label: 'Peuples', one: 'Peuple', icon: 'fa-people-group', tpl: 'fiche', fields: [['longevite', 'Longévité'], ['taille', 'Taille'], ['terres', 'Terres d\'origine'], ['langue', 'Langue'], ['traits', 'Traits', 'textarea']] },
  magie: { label: 'Magie', one: 'Magie', icon: 'fa-hat-wizard', tpl: 'grimoire', fields: [['ecole', 'École ou élément'], ['rang', 'Rang'], ['cout', 'Coût'], ['portee', 'Portée'], ['duree', 'Durée'], ['incantation', 'Incantation'], ['composantes', 'Composantes']] },
  creature: { label: 'Bestiaire', one: 'Créature', icon: 'fa-dragon', tpl: 'fiche', fields: [['nature', 'Nature'], ['habitat', 'Habitat'], ['danger', 'Dangerosité', 'select', ['Inoffensive', 'Faible', 'Modérée', 'Élevée', 'Mortelle', 'Légendaire']], ['taille', 'Taille'], ['faiblesses', 'Faiblesses'], ['butin', 'Butin']] },
  objet: { label: 'Objets', one: 'Objet', icon: 'fa-gem', tpl: 'fiche', fields: [['nature', 'Nature'], ['rarete', 'Rareté', 'select', ['Commun', 'Peu commun', 'Rare', 'Épique', 'Légendaire', 'Unique']], ['valeur', 'Valeur'], ['proprietes', 'Propriétés', 'textarea'], ['origine', 'Origine']] },
  histoire: { label: 'Histoire', one: 'Événement', icon: 'fa-hourglass-half', tpl: 'parchemin', fields: [['epoque', 'Époque'], ['date', 'Date'], ['issue', 'Issue']] },
  croyance: { label: 'Croyances', one: 'Croyance', icon: 'fa-sun', tpl: 'fiche', fields: [['domaine', 'Domaine'], ['symbole', 'Symbole'], ['fideles', 'Fidèles'], ['preceptes', 'Préceptes', 'textarea']] },
  livre: { label: 'Bibliothèque', one: 'Livre', icon: 'fa-book', tpl: 'livre', fields: [['auteur', 'Auteur'], ['langue', 'Langue'], ['ecrit', 'Écrit en'], ['etat', 'État du manuscrit']] },
  note: { label: 'Notes', one: 'Note', icon: 'fa-feather', tpl: 'classique', fields: [] }
};
const TPLS = { fiche: ['Fiche', 'fa-id-card'], parchemin: ['Parchemin', 'fa-scroll'], livre: ['Livre', 'fa-book-open'], grimoire: ['Grimoire', 'fa-book-sparkles'], classique: ['Classique', 'fa-align-left'] };
const RELS = ['Lié à', 'Membre de', 'Dirige', 'Allié de', 'Ennemi de', 'Se trouve à', 'Originaire de', 'Parent de', 'Enfant de', 'Auteur de', 'Écrit par', 'Créé par', 'Gardien de', 'Vénère'];
const ROOT = 'Encyclopédie d\'Éos';

/* ---------- utilitaires ---------- */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const G = k => game.settings.get(ID, k);
const isArt = j => !!j?.flags?.[ID]?.cat && CATS[j.flags[ID].cat];
const A = j => ({ cat: 'note', tpl: '', world: '', tags: [], summary: '', img: '', imgPos: '50% 30%', fields: {}, rels: [], saga: { name: '', tome: '' }, annee: '', ...(j.flags?.[ID] ?? {}) });
const can = (j, lvl) => game.user.isGM || j.testUserPermission(game.user, lvl);
const full = j => can(j, 'OBSERVER');
const level = j => (j.ownership?.default ?? 0);
const enrich = (html, rel) => foundry.applications.ux.TextEditor.implementation.enrichHTML(html ?? '', { secrets: game.user.isGM, relativeTo: rel });
const worlds = () => (G('worlds') || []).filter(w => w?.name);
const wColor = n => worlds().find(w => w.name === n)?.color ?? '#b48a3c';
const cmpName = (a, b) => a.name.localeCompare(b.name, 'fr', { sensitivity: 'base', numeric: true });

function articles() { return game.journal.filter(j => isArt(j) && can(j, 'LIMITED')); }
function sections(j) {
  return j.pages.contents.sort((a, b) => a.sort - b.sort)
    .filter(p => ['text', 'image'].includes(p.type) && (game.user.isGM || p.testUserPermission(game.user, 'OBSERVER')));
}
const pageSecret = p => p.ownership?.default === OWN.NONE;

/* ---------- index des liens (rétroliens) ---------- */
let _idx = null;
function backIndex() {
  if (_idx) return _idx;
  const idx = new Map(); const add = (to, from) => { if (to === from) return; if (!idx.has(to)) idx.set(to, new Set()); idx.get(to).add(from); };
  const ids = new Set(articles().map(j => j.id));
  for (const j of articles()) {
    for (const p of j.pages) {
      const html = p.text?.content ?? '';
      for (const m of html.matchAll(/JournalEntry\.([A-Za-z0-9]{16})/g)) if (ids.has(m[1])) add(m[1], j.id);
    }
    for (const r of A(j).rels) { const id = String(r.uuid ?? '').split('.')[1]; if (ids.has(id)) add(id, j.id); }
  }
  return (_idx = idx);
}
const dirty = () => { _idx = null; Codex.refresh(); };

/* ---------- dossiers ---------- */
async function ensureFolder(cat) {
  let root = game.folders.find(f => f.type === 'JournalEntry' && !f.folder && f.name === ROOT);
  if (!root) root = await Folder.create({ name: ROOT, type: 'JournalEntry', color: '#6e4a1e' });
  let sub = game.folders.find(f => f.type === 'JournalEntry' && f.folder?.id === root.id && f.name === CATS[cat].label);
  if (!sub) sub = await Folder.create({ name: CATS[cat].label, type: 'JournalEntry', folder: root.id });
  return sub;
}

/* ---------- l'application ---------- */
class Codex extends foundry.applications.api.ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: 'encyclopedie-eos', classes: ['eeo-app'], tag: 'section',
    window: { title: 'Encyclopédie d\'Éos', icon: 'fa-solid fa-book-open', resizable: true },
    position: { width: 1140, height: 800 }
  };
  static instance = null;
  static open(id) { this.instance ??= new Codex(); if (id) this.instance.go({ view: 'article', id }); else this.instance.render({ force: true }); return this.instance; }
  // pas de re-rendu automatique pendant l'édition : cela effacerait les champs en cours de saisie
  static refresh() { if (this.instance?.rendered && this.instance.S.view !== 'edit') this.instance.render(); }

  S = { view: 'home', cat: null, world: '*', tag: null, q: '', id: null, tpl: null, saga: null, sort: 'az', spread: 0, back: [] };

  go(patch, push = true) {
    if (push) this.S.back.push({ ...this.S, back: undefined });
    if (this.S.back.length > 40) this.S.back.shift();
    Object.assign(this.S, { tpl: null, spread: 0 }, patch);
    this.render({ force: true });
  }
  goBack() { const p = this.S.back.pop(); if (p) { Object.assign(this.S, p, { back: this.S.back }); this.render(); } }

  async _renderHTML() {
    let main = '';
    try {
      const v = this.S.view;
      if (v === 'article') main = await this.vArticle();
      else if (v === 'edit') main = await this.vEdit();
      else if (v === 'list') main = this.vList();
      else if (v === 'sagas') main = this.vSagas();
      else if (v === 'chrono') main = this.vChrono();
      else main = this.vHome();
    } catch (e) { console.error(`${ID} |`, e); main = `<div class="eeo-empty">Erreur d'affichage : ${esc(e.message)}</div>`; }
    return `<div class="eeo-wrap">${this.vSide()}<main class="eeo-main">${main}</main></div>`;
  }
  _replaceHTML(result, content) {
    const keepScroll = content.querySelector('.eeo-main')?.scrollTop ?? 0;
    content.innerHTML = result;
    const wrap = content.querySelector('.eeo-wrap');
    this.wire(wrap);
    if (this._keep) wrap.querySelector('.eeo-main').scrollTop = keepScroll;
    this._keep = false;
  }

  /* -- barre latérale -- */
  vSide() {
    const all = this.filtered({ ignoreCat: true });
    const n = c => all.filter(j => A(j).cat === c).length;
    const tags = new Map(); for (const j of all) for (const t of A(j).tags) tags.set(t, (tags.get(t) ?? 0) + 1);
    const ws = worlds();
    const gm = game.user.isGM;
    const secrets = gm ? articles().filter(j => level(j) === OWN.NONE).length : 0;
    const act = (k, extra = '') => (this.S.view === k && extra === '' ? 'on' : '');
    return `<aside class="eeo-side">
      <div class="eeo-brand"><span class="fa-solid fa-book-open"></span><div><b>Encyclopédie</b><small>d'Éos</small></div></div>
      <label class="eeo-search"><span class="fa-solid fa-magnifying-glass"></span><input type="text" name="q" value="${esc(this.S.q)}" placeholder="Chercher un nom, un mot…" autocomplete="off" spellcheck="false"></label>
      ${ws.length > 1 ? `<div class="eeo-worlds"><a data-world="*" class="${this.S.world === '*' ? 'on' : ''}">Tous</a>${ws.map(w => `<a data-world="${esc(w.name)}" class="${this.S.world === w.name ? 'on' : ''}" style="--c:${esc(w.color)}">${esc(w.name)}</a>`).join('')}</div>` : ''}
      <nav class="eeo-nav">
        <a data-go="home" class="${act('home')}"><span class="fa-solid fa-house-chimney-crack"></span>Accueil</a>
        <h6>Catégories</h6>
        ${Object.entries(CATS).map(([k, c]) => `<a data-cat="${k}" class="${this.S.view === 'list' && this.S.cat === k ? 'on' : ''}"><span class="fa-solid ${c.icon}"></span>${c.label}<b>${n(k)}</b></a>`).join('')}
        <h6>Parcourir</h6>
        <a data-go="list" class="${this.S.view === 'list' && !this.S.cat ? 'on' : ''}"><span class="fa-solid fa-arrow-down-a-z"></span>Tout, de A à Z<b>${all.length}</b></a>
        <a data-go="sagas" class="${act('sagas')}"><span class="fa-solid fa-books"></span>Sagas</a>
        <a data-go="chrono" class="${act('chrono')}"><span class="fa-solid fa-timeline"></span>Chronologie</a>
        ${gm ? `<h6>Maître du jeu</h6>
        <a data-act="new"><span class="fa-solid fa-plus"></span>Nouvel article</a>
        <a data-go="secrets" class="${this.S.view === 'list' && this.S.cat === '__secret' ? 'on' : ''}"><span class="fa-solid fa-eye-slash"></span>Secrets<b>${secrets}</b></a>
        <a data-act="settings"><span class="fa-solid fa-gear"></span>Réglages</a>
        <div class="eeo-drop" data-drop><span class="fa-solid fa-file-import"></span>Glisse ici un journal existant pour le convertir en article</div>` : ''}
      </nav>
      ${tags.size ? `<div class="eeo-tags"><h6>Étiquettes</h6>${[...tags.entries()].sort((a, b) => b[1] - a[1]).slice(0, 40).map(([t, c]) => `<a data-tag="${esc(t)}" class="${this.S.tag === t ? 'on' : ''}">${esc(t)}<i>${c}</i></a>`).join('')}</div>` : ''}
    </aside>`;
  }

  filtered({ ignoreCat = false } = {}) {
    const q = norm(this.S.q);
    return articles().filter(j => {
      const a = A(j);
      if (this.S.world !== '*' && a.world && a.world !== this.S.world) return false;
      if (!ignoreCat && this.S.cat === '__secret') { if (level(j) !== OWN.NONE) return false; }
      else if (!ignoreCat && this.S.cat && a.cat !== this.S.cat) return false;
      if (!ignoreCat && this.S.tag && !a.tags.includes(this.S.tag)) return false;
      if (q) {
        const hay = norm(`${j.name} ${a.summary} ${a.tags.join(' ')} ${Object.values(a.fields).join(' ')} ${a.saga?.name ?? ''} ${full(j) ? j.pages.map(p => p.name + ' ' + (p.text?.content ?? '').replace(/<[^>]+>/g, ' ')).join(' ') : ''}`);
        if (!q.split(/\s+/).every(w => hay.includes(w))) return false;
      }
      return true;
    });
  }

  /* -- cartes -- */
  card(j) {
    const a = A(j); const c = CATS[a.cat]; const lv = level(j);
    const badge = game.user.isGM ? (lv === OWN.NONE ? '<span class="eeo-badge sec" data-tooltip="Secret"><span class="fa-solid fa-eye-slash"></span></span>' : lv === OWN.LIMITED ? '<span class="eeo-badge lim" data-tooltip="Connu de nom"><span class="fa-solid fa-eye-low-vision"></span></span>' : '') : '';
    return `<a class="eeo-card" data-open="${j.id}" draggable="true" data-uuid="${j.uuid}">
      <span class="eeo-cimg" style="${a.img ? `background-image:url(&quot;${esc(a.img)}&quot;);background-position:${esc(a.imgPos)}` : ''}">${a.img ? '' : `<span class="fa-solid ${c.icon}"></span>`}</span>
      ${badge}<span class="eeo-cbody"><small><span class="fa-solid ${c.icon}"></span>${c.one}${a.world ? ` · <i style="color:${esc(wColor(a.world))}">${esc(a.world)}</i>` : ''}</small><b>${esc(j.name)}</b>${a.summary ? `<em>${esc(a.summary)}</em>` : ''}</span></a>`;
  }

  /* -- vues -- */
  vHome() {
    const all = this.filtered({ ignoreCat: true });
    const recent = [...all].sort((x, y) => (y._stats?.modifiedTime ?? 0) - (x._stats?.modifiedTime ?? 0)).slice(0, 8);
    const sagas = this.sagaMap(all);
    return `<div class="eeo-home">
      <header class="eeo-hero"><span class="eeo-hero-orn"></span><h1>Encyclopédie d'Éos</h1><p>${all.length} article${all.length > 1 ? 's' : ''} · ${Object.keys(CATS).filter(k => all.some(j => A(j).cat === k)).length} catégories · ${sagas.size} saga${sagas.size > 1 ? 's' : ''}</p><span class="eeo-hero-orn"></span></header>
      <div class="eeo-tiles">${Object.entries(CATS).map(([k, c]) => { const n = all.filter(j => A(j).cat === k).length; return `<a class="eeo-tile" data-cat="${k}"><span class="fa-solid ${c.icon}"></span><b>${c.label}</b><small>${n} article${n > 1 ? 's' : ''}</small></a>`; }).join('')}</div>
      ${recent.length ? `<h2 class="eeo-h2"><span>Derniers écrits</span></h2><div class="eeo-grid">${recent.map(j => this.card(j)).join('')}</div>` : `<div class="eeo-empty">${game.user.isGM ? 'L\'encyclopédie est vide. Crée un article ou glisse un journal existant dans la zone à gauche.' : 'Aucun article ne t\'a encore été révélé.'}</div>`}
    </div>`;
  }
  vList() {
    const list = this.filtered();
    const s = this.S.sort;
    list.sort(s === 'recent' ? (x, y) => (y._stats?.modifiedTime ?? 0) - (x._stats?.modifiedTime ?? 0)
      : s === 'chrono' ? (x, y) => (Number(A(x).annee) || 1e12) - (Number(A(y).annee) || 1e12) || cmpName(x, y) : cmpName);
    const c = this.S.cat && this.S.cat !== '__secret' ? CATS[this.S.cat] : null;
    const title = this.S.cat === '__secret' ? 'Secrets' : c ? c.label : this.S.q ? `Recherche « ${esc(this.S.q)} »` : 'Tout, de A à Z';
    let body;
    if (s === 'az' && list.length > 12) {
      const groups = new Map(); for (const j of list) { const l = norm(j.name)[0]?.toUpperCase() ?? '#'; const k = /[A-Z]/.test(l) ? l : '#'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(j); }
      body = `<div class="eeo-letters">${[...groups.keys()].map(l => `<a data-letter="${l}">${l}</a>`).join('')}</div>` + [...groups.entries()].map(([l, js]) => `<h3 class="eeo-letter" id="eeo-l-${l}">${l}</h3><div class="eeo-grid">${js.map(j => this.card(j)).join('')}</div>`).join('');
    } else body = list.length ? `<div class="eeo-grid">${list.map(j => this.card(j)).join('')}</div>` : '<div class="eeo-empty">Rien ne correspond.</div>';
    return `<div class="eeo-list"><header class="eeo-lhead"><h1>${c ? `<span class="fa-solid ${c.icon}"></span>` : ''}${title}</h1>
      ${this.S.tag ? `<a class="eeo-chip on" data-tag="${esc(this.S.tag)}">${esc(this.S.tag)} <span class="fa-solid fa-xmark"></span></a>` : ''}
      <span class="eeo-count">${list.length} article${list.length > 1 ? 's' : ''}</span>
      <label class="eeo-sort">Trier<select name="sort"><option value="az" ${s === 'az' ? 'selected' : ''}>De A à Z</option><option value="recent" ${s === 'recent' ? 'selected' : ''}>Récents</option><option value="chrono" ${s === 'chrono' ? 'selected' : ''}>Chronologique</option></select></label>
      ${c && game.user.isGM ? `<a class="eeo-btn" data-act="new" data-newcat="${this.S.cat}"><span class="fa-solid fa-plus"></span>${c.one}</a>` : ''}</header>${body}</div>`;
  }
  sagaMap(list = articles()) {
    const m = new Map();
    for (const j of list) { const s = A(j).saga; if (!s?.name) continue; if (!m.has(s.name)) m.set(s.name, []); m.get(s.name).push(j); }
    for (const js of m.values()) js.sort((x, y) => (Number(A(x).saga.tome) || 999) - (Number(A(y).saga.tome) || 999) || cmpName(x, y));
    return m;
  }
  vSagas() {
    const m = this.sagaMap(this.filtered({ ignoreCat: true }));
    if (this.S.saga && m.has(this.S.saga)) {
      const js = m.get(this.S.saga);
      return `<div class="eeo-list"><header class="eeo-lhead"><a class="eeo-btn ghost" data-go="sagas"><span class="fa-solid fa-arrow-left"></span>Sagas</a><h1><span class="fa-solid fa-books"></span>${esc(this.S.saga)}</h1><span class="eeo-count">${js.length} tome${js.length > 1 ? 's' : ''}</span></header>
        <div class="eeo-shelf">${js.map(j => { const a = A(j); return `<a class="eeo-tome" data-open="${j.id}" style="--c:${esc(wColor(a.world))}"><span class="eeo-spine">${a.saga.tome ? `<i>Tome ${esc(a.saga.tome)}</i>` : ''}<b>${esc(j.name)}</b></span>${a.img ? `<span class="eeo-tcover" style="background-image:url(&quot;${esc(a.img)}&quot;)"></span>` : ''}</a>`; }).join('')}</div></div>`;
    }
    return `<div class="eeo-list"><header class="eeo-lhead"><h1><span class="fa-solid fa-books"></span>Sagas</h1><span class="eeo-count">${m.size}</span></header>
      ${m.size ? `<div class="eeo-sagas">${[...m.entries()].sort((a, b) => a[0].localeCompare(b[0], 'fr')).map(([n, js]) => `<a class="eeo-saga" data-saga="${esc(n)}"><span class="fa-solid fa-books"></span><b>${esc(n)}</b><small>${js.length} tome${js.length > 1 ? 's' : ''} · ${js.map(j => esc(j.name)).slice(0, 3).join(', ')}${js.length > 3 ? '…' : ''}</small></a>`).join('')}</div>` : '<div class="eeo-empty">Aucune saga. Dans un article, renseigne « Saga » et « Tome » pour relier des livres ou des chapitres entre eux.</div>'}</div>`;
  }
  vChrono() {
    const list = this.filtered({ ignoreCat: true }).filter(j => A(j).annee !== '' && A(j).annee != null && !isNaN(Number(A(j).annee)))
      .sort((x, y) => Number(A(x).annee) - Number(A(y).annee) || cmpName(x, y));
    return `<div class="eeo-list"><header class="eeo-lhead"><h1><span class="fa-solid fa-timeline"></span>Chronologie</h1><span class="eeo-count">${list.length} date${list.length > 1 ? 's' : ''}</span></header>
      ${list.length ? `<ol class="eeo-time">${list.map(j => { const a = A(j); const c = CATS[a.cat]; return `<li><span class="eeo-year">${esc(a.annee)}</span><a data-open="${j.id}"><span class="fa-solid ${c.icon}"></span><b>${esc(j.name)}</b>${a.fields?.epoque || a.fields?.date ? `<small>${esc([a.fields.epoque, a.fields.date].filter(Boolean).join(' · '))}</small>` : ''}${a.summary ? `<em>${esc(a.summary)}</em>` : ''}</a></li>`; }).join('')}</ol>` : '<div class="eeo-empty">Aucune date. Renseigne le champ « Année » d\'un article pour le placer sur la frise.</div>'}</div>`;
  }

  /* -- article -- */
  async vArticle() {
    const j = game.journal.get(this.S.id);
    if (!j || !isArt(j) || !can(j, 'LIMITED')) return '<div class="eeo-empty">Article introuvable ou non révélé.</div>';
    const a = A(j); const c = CATS[a.cat];
    const tpl = this.S.tpl || a.tpl || c.tpl;
    const isFull = full(j);
    const secs = isFull ? await Promise.all(sections(j).map(async p => ({
      p, title: p.name, secret: pageSecret(p), html: p.type === 'image' ? `<figure class="eeo-pimg"><img src="${esc(p.src)}" alt=""><figcaption>${esc(p.image?.caption ?? '')}</figcaption></figure>` : await enrich(p.text?.content, p)
    }))) : [];
    const fields = isFull ? c.fields.map(([k, label]) => [label, a.fields?.[k]]).filter(([, v]) => v) : [];
    if (isFull && a.annee !== '' && a.annee != null) fields.push(['Année', a.annee]);
    const D = { j, a, c, secs, fields, isFull, tpl };
    const body = tpl === 'parchemin' ? this.tParch(D) : tpl === 'livre' ? this.tBook(D) : tpl === 'grimoire' ? this.tGrim(D) : tpl === 'classique' ? this.tClassic(D) : this.tFiche(D);
    const gm = game.user.isGM; const lv = level(j);
    const rev = lv === OWN.NONE ? ['fa-eye-slash', 'Secret', 'st-sec'] : lv === OWN.LIMITED ? ['fa-eye-low-vision', 'Connu de nom', 'st-lim'] : ['fa-eye', 'Révélé', 'st-rev'];
    return `<div class="eeo-art" data-id="${j.id}">
      <div class="eeo-bar">
        <a class="eeo-btn ghost" data-act="back" data-tooltip="Retour"><span class="fa-solid fa-arrow-left"></span></a>
        <nav class="eeo-crumb"><a data-cat="${a.cat}"><span class="fa-solid ${c.icon}"></span>${c.label}</a><span class="fa-solid fa-angle-right"></span><b>${esc(j.name)}</b></nav>
        <div class="eeo-tpls">${Object.entries(TPLS).map(([k, [l, ic]]) => `<a data-tpl="${k}" class="${tpl === k ? 'on' : ''}" data-tooltip="${l}"><span class="fa-solid ${ic}"></span></a>`).join('')}</div>
        ${gm ? `<a class="eeo-btn rev ${rev[2]}" data-act="reveal" data-tooltip="Changer ce que voient les joueurs"><span class="fa-solid ${rev[0]}"></span>${rev[1]}</a>
        <a class="eeo-btn" data-act="edit"><span class="fa-solid fa-pen-nib"></span>Modifier</a>
        <a class="eeo-btn ghost" data-act="sheet" data-tooltip="Ouvrir le journal Foundry"><span class="fa-solid fa-book"></span></a>` : ''}
      </div>
      <div class="eeo-stage">${body}</div>
      ${isFull ? this.linksHTML(j, a) : ''}
    </div>`;
  }
  head(D, cls = '') { return `<h1 class="eeo-title ${cls}">${esc(D.j.name)}</h1><p class="eeo-sub"><span class="fa-solid ${D.c.icon}"></span>${D.c.one}${D.a.world ? ` · ${esc(D.a.world)}` : ''}${D.a.saga?.name ? ` · ${esc(D.a.saga.name)}${D.a.saga.tome ? `, tome ${esc(D.a.saga.tome)}` : ''}` : ''}</p>`; }
  secHTML(D, cls = '') {
    if (!D.isFull) return '<p class="eeo-limited"><span class="fa-solid fa-eye-low-vision"></span>Vous n\'en connaissez que le nom.</p>';
    return D.secs.map(s => `<section class="eeo-sec ${cls} ${s.secret ? 'is-secret' : ''}">${D.secs.length > 1 || s.title !== 'Description' ? `<h2>${esc(s.title)}${s.secret && game.user.isGM ? ' <span class="eeo-sbadge"><span class="fa-solid fa-eye-slash"></span>secret</span>' : ''}</h2>` : ''}<div class="eeo-prose">${s.html}</div></section>`).join('');
  }
  fieldsHTML(D, cls = 'eeo-dl') { return D.fields.length ? `<dl class="${cls}">${D.fields.map(([l, v]) => `<div><dt>${esc(l)}</dt><dd>${esc(v).replace(/\n/g, '<br>')}</dd></div>`).join('')}</dl>` : ''; }
  imgStyle(D) { return D.a.img ? `background-image:url(&quot;${esc(D.a.img)}&quot;);background-position:${esc(D.a.imgPos)}` : ''; }

  tFiche(D) {
    return `<article class="eeo-t eeo-fiche">
      <header class="eeo-fhead ${D.a.img ? 'has-img' : ''}" style="${this.imgStyle(D)}"><div class="eeo-fhead-in">${this.head(D)}</div></header>
      <div class="eeo-fcols">
        <aside class="eeo-info">${D.a.img ? `<div class="eeo-portrait" style="${this.imgStyle(D)}"></div>` : `<div class="eeo-portrait none"><span class="fa-solid ${D.c.icon}"></span></div>`}
          <h3>${esc(D.j.name)}</h3>${this.fieldsHTML(D)}${D.a.tags.length ? `<div class="eeo-itags">${D.a.tags.map(t => `<a data-tag="${esc(t)}">${esc(t)}</a>`).join('')}</div>` : ''}</aside>
        <div class="eeo-fmain">${D.a.summary ? `<p class="eeo-lede">${esc(D.a.summary)}</p>` : ''}${this.secHTML(D)}</div>
      </div></article>`;
  }
  tParch(D) {
    return `<article class="eeo-t eeo-parch"><div class="eeo-roll"></div><div class="eeo-psheet">
      ${D.a.img ? `<div class="eeo-vignette" style="${this.imgStyle(D)}"></div>` : ''}
      ${this.head(D, 'center')}<div class="eeo-rule"><span class="fa-solid fa-feather-pointed"></span></div>
      ${D.a.summary ? `<p class="eeo-lede center">${esc(D.a.summary)}</p>` : ''}
      ${D.fields.length ? `<p class="eeo-inline">${D.fields.map(([l, v]) => `<span><i>${esc(l)}</i> ${esc(v)}</span>`).join('')}</p>` : ''}
      <div class="eeo-dropcap">${this.secHTML(D)}</div></div><div class="eeo-roll bottom"></div></article>`;
  }
  tGrim(D) {
    return `<article class="eeo-t eeo-grim"><div class="eeo-gframe">
      <div class="eeo-sigil">${D.a.img ? `<span class="eeo-sigimg" style="${this.imgStyle(D)}"></span>` : `<span class="fa-solid ${D.c.icon}"></span>`}</div>
      ${this.head(D, 'center')}
      ${D.a.summary ? `<p class="eeo-incant">${esc(D.a.summary)}</p>` : ''}
      ${D.fields.length ? `<div class="eeo-runes">${D.fields.map(([l, v]) => `<div><small>${esc(l)}</small><b>${esc(v)}</b></div>`).join('')}</div>` : ''}
      ${this.secHTML(D, 'grim')}</div></article>`;
  }
  tClassic(D) {
    return `<article class="eeo-t eeo-classic">${this.head(D)}
      ${D.a.img ? `<div class="eeo-cbanner" style="${this.imgStyle(D)}"></div>` : ''}
      ${D.a.summary ? `<p class="eeo-lede">${esc(D.a.summary)}</p>` : ''}${this.fieldsHTML(D, 'eeo-dl table')}${this.secHTML(D)}</article>`;
  }
  /* Livre : le texte coule en colonnes de la hauteur d'une page ; tourner la page fait glisser d'une double page. */
  tBook(D) {
    const blocks = [`<div class="eeo-bk-title">${D.a.img ? `<div class="eeo-bimg" style="${this.imgStyle(D)}"></div>` : `<div class="eeo-bimg none"><span class="fa-solid ${D.c.icon}"></span></div>`}${this.head(D, 'center')}<div class="eeo-rule"><span class="fa-solid fa-feather-pointed"></span></div>${D.a.summary ? `<p class="eeo-lede center">${esc(D.a.summary)}</p>` : ''}</div>`];
    if (D.fields.length) blocks.push(`<section class="eeo-bk-sec"><h2>Informations</h2>${this.fieldsHTML(D)}</section>`);
    if (!D.isFull) blocks.push(`<section class="eeo-bk-sec">${this.secHTML(D)}</section>`);
    for (const s of D.secs) blocks.push(`<section class="eeo-bk-sec ${s.secret ? 'is-secret' : ''}"><h2>${esc(s.title)}${s.secret && game.user.isGM ? ' <span class="eeo-sbadge"><span class="fa-solid fa-eye-slash"></span>secret</span>' : ''}</h2><div class="eeo-prose">${s.html}</div></section>`);
    blocks.push('<div class="eeo-bk-end"><span class="fa-solid fa-feather-pointed"></span></div>');
    return `<article class="eeo-t eeo-book">
      <a class="eeo-turn prev" data-turn="-1"><span class="fa-solid fa-chevron-left"></span></a>
      <div class="eeo-spread"><div class="eeo-view"><div class="eeo-flow">${blocks.join('')}</div></div>
        <span class="eeo-pnum l"></span><span class="eeo-pnum r"></span><div class="eeo-flip"></div></div>
      <a class="eeo-turn next" data-turn="1"><span class="fa-solid fa-chevron-right"></span></a>
      <div class="eeo-bnav"></div></article>`;
  }
  layoutBook(dir) {
    const book = this.element?.querySelector('.eeo-book'); if (!book) return;
    const view = book.querySelector('.eeo-view'), flow = book.querySelector('.eeo-flow'), spread = book.querySelector('.eeo-spread');
    const gap = 64, W = view.clientWidth, H = view.clientHeight; if (!W || !H) return;
    const colW = (W - gap) / 2;
    flow.style.width = `${W}px`; flow.style.height = `${H}px`; flow.style.columnWidth = `${colW}px`; flow.style.columnGap = `${gap}px`;
    const cols = Math.max(1, Math.round((flow.scrollWidth + gap) / (colW + gap)));
    const spreads = Math.max(1, Math.ceil(cols / 2));
    this.S.spread = Math.max(0, Math.min(this.S.spread, spreads - 1));
    const i = this.S.spread;
    flow.classList.toggle('anim', !!dir);
    flow.style.transform = `translateX(${-i * (W + gap)}px)`;
    book.querySelector('.eeo-pnum.l').textContent = String(i * 2 + 1);
    book.querySelector('.eeo-pnum.r').textContent = i * 2 + 2 <= cols ? String(i * 2 + 2) : '';
    book.querySelector('.eeo-turn.prev').classList.toggle('off', i === 0);
    book.querySelector('.eeo-turn.next').classList.toggle('off', i >= spreads - 1);
    book.querySelector('.eeo-bnav').innerHTML = spreads > 1 ? Array.from({ length: spreads }, (_, k) => `<a data-spread="${k}" class="${k === i ? 'on' : ''}"></a>`).join('') : '';
    if (dir) { spread.classList.remove('flip-next', 'flip-prev'); void spread.offsetWidth; spread.classList.add(dir > 0 ? 'flip-next' : 'flip-prev'); }
  }
  linksHTML(j, a) {
    const rels = a.rels.map(r => ({ ...r, doc: fromUuidSync(r.uuid) })).filter(r => r.doc && (game.user.isGM || r.doc.testUserPermission?.(game.user, 'LIMITED')));
    const back = [...(backIndex().get(j.id) ?? [])].map(id => game.journal.get(id)).filter(x => x && can(x, 'LIMITED'));
    const saga = a.saga?.name ? this.sagaMap().get(a.saga.name) ?? [] : [];
    const si = saga.findIndex(x => x.id === j.id);
    if (!rels.length && !back.length && saga.length < 2) return '';
    const chip = (d, label) => `<a class="eeo-link" data-open="${d.id}"><span class="fa-solid ${CATS[A(d).cat]?.icon ?? 'fa-book'}"></span>${label ? `<i>${esc(label)}</i>` : ''}<b>${esc(d.name)}</b></a>`;
    return `<footer class="eeo-links">
      ${saga.length > 1 ? `<div class="eeo-sagabar"><a class="${si > 0 ? '' : 'off'}" ${si > 0 ? `data-open="${saga[si - 1].id}"` : ''}><span class="fa-solid fa-arrow-left"></span>${si > 0 ? esc(saga[si - 1].name) : ''}</a><span data-saga="${esc(a.saga.name)}"><span class="fa-solid fa-books"></span>${esc(a.saga.name)} · ${si + 1} / ${saga.length}</span><a class="${si < saga.length - 1 ? '' : 'off'}" ${si < saga.length - 1 ? `data-open="${saga[si + 1].id}"` : ''}>${si < saga.length - 1 ? esc(saga[si + 1].name) : ''}<span class="fa-solid fa-arrow-right"></span></a></div>` : ''}
      ${rels.length ? `<div><h4>Relations</h4><div class="eeo-linkrow">${rels.map(r => chip(r.doc, r.label)).join('')}</div></div>` : ''}
      ${back.length ? `<div><h4>Cité dans</h4><div class="eeo-linkrow">${back.sort(cmpName).map(d => chip(d)).join('')}</div></div>` : ''}
    </footer>`;
  }

  /* -- édition (MJ) -- */
  async vEdit() {
    const j = game.journal.get(this.S.id); if (!j) return '<div class="eeo-empty">Article introuvable.</div>';
    const a = A(j); const c = CATS[a.cat];
    const ws = worlds();
    const opt = (v, cur, l = v) => `<option value="${esc(v)}" ${v === cur ? 'selected' : ''}>${esc(l)}</option>`;
    const fld = ([k, label, kind, opts]) => {
      const v = a.fields?.[k] ?? '';
      if (kind === 'select') return `<label>${esc(label)}<select name="f.${k}">${opt('', v, '—')}${opts.map(o => opt(o, v)).join('')}</select></label>`;
      if (kind === 'textarea') return `<label class="wide">${esc(label)}<textarea name="f.${k}" rows="2">${esc(v)}</textarea></label>`;
      return `<label>${esc(label)}<input type="text" name="f.${k}" value="${esc(v)}"></label>`;
    };
    const pages = j.pages.contents.sort((x, y) => x.sort - y.sort);
    return `<form class="eeo-edit" autocomplete="off">
      <div class="eeo-bar"><a class="eeo-btn ghost" data-act="cancel-edit"><span class="fa-solid fa-arrow-left"></span>Annuler</a><h1>Modifier l'article</h1><a class="eeo-btn gold" data-act="save"><span class="fa-solid fa-check"></span>Enregistrer</a></div>
      <div class="eeo-ecols">
        <div class="eeo-ecol">
          <fieldset><legend>Identité</legend>
            <label class="wide">Titre<input type="text" name="name" value="${esc(j.name)}"></label>
            <label>Catégorie<select name="cat">${Object.entries(CATS).map(([k, x]) => opt(k, a.cat, x.one)).join('')}</select></label>
            <label>Gabarit<select name="tpl">${opt('', a.tpl, `Par défaut (${TPLS[c.tpl][0]})`)}${Object.entries(TPLS).map(([k, [l]]) => opt(k, a.tpl, l)).join('')}</select></label>
            <label>Monde<select name="world">${opt('', a.world, '—')}${ws.map(w => opt(w.name, a.world)).join('')}</select></label>
            <label>Année <small>(chronologie)</small><input type="number" name="annee" value="${esc(a.annee)}" step="1"></label>
            <label class="wide">Étiquettes <small>(séparées par des virgules)</small><input type="text" name="tags" value="${esc(a.tags.join(', '))}"></label>
            <label class="wide">Résumé <small>(visible même quand l'article n'est « connu que de nom »)</small><textarea name="summary" rows="3">${esc(a.summary)}</textarea></label>
          </fieldset>
          <fieldset><legend>Image</legend>
            <div class="eeo-imgrow"><div class="eeo-imgprev" style="${a.img ? `background-image:url(&quot;${esc(a.img)}&quot;);background-position:${esc(a.imgPos)}` : ''}"></div>
            <div><div class="eeo-frow"><input type="text" name="img" value="${esc(a.img)}" placeholder="Chemin de l'image"><a class="eeo-btn" data-act="pick"><span class="fa-solid fa-folder-open"></span></a></div>
            <label>Cadrage horizontal<input type="range" name="px" min="0" max="100" value="${parseInt(a.imgPos) || 50}"></label>
            <label>Cadrage vertical<input type="range" name="py" min="0" max="100" value="${parseInt(String(a.imgPos).split(' ')[1]) || 30}"></label></div></div>
          </fieldset>
          <fieldset><legend>Saga</legend>
            <label>Nom de la saga<input type="text" name="saga" value="${esc(a.saga?.name ?? '')}" list="eeo-sagas"><datalist id="eeo-sagas">${[...this.sagaMap().keys()].map(n => `<option value="${esc(n)}">`).join('')}</datalist></label>
            <label>Tome ou chapitre<input type="number" name="tome" value="${esc(a.saga?.tome ?? '')}" step="1"></label>
          </fieldset>
        </div>
        <div class="eeo-ecol">
          <fieldset><legend>Fiche · ${esc(c.one)}</legend>${c.fields.length ? c.fields.map(fld).join('') : '<p class="eeo-note">Pas de champ pour cette catégorie.</p>'}</fieldset>
          <fieldset><legend>Relations</legend>
            <div class="eeo-rels">${a.rels.map((r, i) => { const d = fromUuidSync(r.uuid); return `<div class="eeo-rel" data-i="${i}"><select name="rl.${i}">${RELS.map(x => opt(x, r.label)).join('')}${RELS.includes(r.label) ? '' : opt(r.label, r.label)}</select><b>${esc(d?.name ?? 'introuvable')}</b><a data-act="relrm" data-i="${i}"><span class="fa-solid fa-xmark"></span></a></div>`; }).join('') || '<p class="eeo-note">Aucune relation.</p>'}</div>
            <div class="eeo-frow"><input type="text" name="relq" placeholder="Chercher un article à relier…"></div><div class="eeo-relhits"></div>
          </fieldset>
          <fieldset><legend>Sections</legend>
            <p class="eeo-note">Chaque section est une page du journal. Le texte se modifie dans l'éditeur de Foundry, où tu peux glisser un article de l'encyclopédie pour créer un lien.</p>
            <div class="eeo-pages">${pages.map((p, i) => `<div class="eeo-page"><span class="fa-solid ${p.type === 'image' ? 'fa-image' : 'fa-align-left'}"></span><b>${esc(p.name)}</b>
              <a data-act="psecret" data-p="${p.id}" class="${pageSecret(p) ? 'sec' : ''}" data-tooltip="${pageSecret(p) ? 'Secrète : seul le MJ la voit' : 'Visible si l\'article est révélé'}"><span class="fa-solid ${pageSecret(p) ? 'fa-eye-slash' : 'fa-eye'}"></span></a>
              <a data-act="pup" data-p="${p.id}" class="${i === 0 ? 'off' : ''}"><span class="fa-solid fa-arrow-up"></span></a>
              <a data-act="pedit" data-p="${p.id}" data-tooltip="Écrire"><span class="fa-solid fa-pen-nib"></span></a>
              <a data-act="pdel" data-p="${p.id}" data-tooltip="Supprimer"><span class="fa-solid fa-trash"></span></a></div>`).join('')}</div>
            <div class="eeo-frow"><a class="eeo-btn" data-act="padd"><span class="fa-solid fa-plus"></span>Section de texte</a><a class="eeo-btn" data-act="padd-img"><span class="fa-solid fa-image"></span>Image</a></div>
          </fieldset>
        </div>
      </div></form>`;
  }
  readEdit(form) {
    const j = game.journal.get(this.S.id); const a = A(j);
    const v = n => form.querySelector(`[name="${n}"]`)?.value ?? '';
    const cat = v('cat');
    const fields = { ...a.fields };
    for (const [k] of (CATS[cat]?.fields ?? [])) { const el = form.querySelector(`[name="f.${k}"]`); if (el) fields[k] = el.value.trim(); }
    const rels = a.rels.map((r, i) => ({ ...r, label: form.querySelector(`[name="rl.${i}"]`)?.value || r.label }));
    return {
      name: v('name').trim() || j.name,
      data: { cat, tpl: v('tpl'), world: v('world'), annee: v('annee').trim(), tags: v('tags').split(',').map(t => t.trim()).filter(Boolean),
        summary: v('summary').trim(), img: v('img').trim(), imgPos: `${v('px') || 50}% ${v('py') || 30}%`, fields, rels,
        saga: { name: v('saga').trim(), tome: v('tome').trim() } }
    };
  }
  async saveEdit(form, stay = false) {
    const j = game.journal.get(this.S.id); const { name, data } = this.readEdit(form);
    await j.update({ name, [`flags.${ID}`]: data });
    if (!stay) this.go({ view: 'article', id: j.id }, false);
  }

  /* -- écouteurs (posés sur .eeo-wrap, recréé à chaque rendu) -- */
  wire(w) {
    const input = w.querySelector('input[name="q"]'); let deb;
    input?.addEventListener('input', () => { clearTimeout(deb); deb = setTimeout(() => { this.S.q = input.value.trim(); const pos = input.selectionStart; this.S.view = this.S.q ? 'list' : (this.S.view === 'list' && !this.S.cat ? 'home' : this.S.view); this.render().then(() => { const i = this.element.querySelector('input[name="q"]'); i?.focus(); i?.setSelectionRange(pos, pos); }); }, 220); });
    input?.addEventListener('keydown', ev => ev.stopPropagation());
    w.querySelector('select[name="sort"]')?.addEventListener('change', ev => { this.S.sort = ev.target.value; this.render(); });
    w.addEventListener('click', ev => this.onClick(ev, w));
    w.addEventListener('dragstart', ev => {
      const c = ev.target.closest('[data-uuid]'); if (!c) return;
      ev.dataTransfer.setData('text/plain', JSON.stringify({ type: 'JournalEntry', uuid: c.dataset.uuid }));
    });
    const drop = w.querySelector('[data-drop]');
    if (drop) {
      drop.addEventListener('dragover', ev => { ev.preventDefault(); drop.classList.add('over'); });
      drop.addEventListener('dragleave', () => drop.classList.remove('over'));
      drop.addEventListener('drop', async ev => {
        ev.preventDefault(); drop.classList.remove('over');
        let d; try { d = JSON.parse(ev.dataTransfer.getData('text/plain')); } catch (e) { return; }
        const doc = d?.uuid ? await fromUuid(d.uuid) : null;
        const j = doc?.documentName === 'JournalEntry' ? doc : doc?.parent?.documentName === 'JournalEntry' ? doc.parent : null;
        if (!j) return ui.notifications.warn('Glisse un journal (ou une de ses pages) depuis l\'onglet Journal.');
        convertDialog(j);
      });
    }
    // édition : image, recherche de relations
    const form = w.querySelector('form.eeo-edit');
    if (form) {
      const prev = () => { const p = form.querySelector('.eeo-imgprev'); const img = form.querySelector('[name="img"]').value.trim(); p.style.backgroundImage = img ? `url("${img.replace(/"/g, '\\"')}")` : ''; p.style.backgroundPosition = `${form.querySelector('[name="px"]').value}% ${form.querySelector('[name="py"]').value}%`; };
      form.addEventListener('input', ev => { if (['img', 'px', 'py'].includes(ev.target.name)) prev(); if (ev.target.name === 'relq') this.relSearch(form); });
      form.addEventListener('change', ev => { if (ev.target.name === 'cat') { this.saveEdit(form, true).then(() => this.render()); } });
      form.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Enter' && ev.target.tagName === 'INPUT') ev.preventDefault(); });
      form.addEventListener('submit', ev => ev.preventDefault());
    }
    // liens internes du texte enrichi : naviguer dans l'encyclopédie
    w.querySelectorAll('.eeo-prose a.content-link[data-uuid]').forEach(link => link.addEventListener('click', ev => {
      const uuid = link.dataset.uuid; const doc = fromUuidSync(uuid);
      const j = doc?.documentName === 'JournalEntry' ? doc : doc?.parent?.documentName === 'JournalEntry' ? doc.parent : null;
      if (j && isArt(j) && can(j, 'LIMITED')) { ev.preventDefault(); ev.stopPropagation(); this.go({ view: 'article', id: j.id }); }
    }, true));
    // livre : flèches du clavier
    const book = w.querySelector('.eeo-book');
    if (book) {
      book.tabIndex = 0; book.addEventListener('keydown', ev => { if (ev.key === 'ArrowRight') this.turn(1); if (ev.key === 'ArrowLeft') this.turn(-1); });
      // mise en page après chargement des polices et images, puis à chaque redimensionnement de la fenêtre
      requestAnimationFrame(() => this.layoutBook());
      document.fonts?.ready?.then(() => this.layoutBook());
      book.querySelectorAll('img').forEach(im => im.complete || im.addEventListener('load', () => this.layoutBook(), { once: true }));
      this._ro?.disconnect(); this._ro = new ResizeObserver(() => this.layoutBook()); this._ro.observe(book.querySelector('.eeo-view'));
    } else { this._ro?.disconnect(); this._ro = null; }
  }
  turn(d) { const b = this.element.querySelector('.eeo-book'); if (!b || b.querySelector(`.eeo-turn.${d > 0 ? 'next' : 'prev'}`)?.classList.contains('off')) return; this.S.spread += d; this.layoutBook(d); }
  relSearch(form) {
    const q = norm(form.querySelector('[name="relq"]').value); const box = form.querySelector('.eeo-relhits');
    if (!q) { box.innerHTML = ''; return; }
    const hits = articles().filter(x => x.id !== this.S.id && norm(x.name).includes(q)).slice(0, 8);
    box.innerHTML = hits.map(x => `<a data-act="reladd" data-uuid="${x.uuid}"><span class="fa-solid ${CATS[A(x).cat].icon}"></span>${esc(x.name)}</a>`).join('') || '<p class="eeo-note">Aucun article.</p>';
  }
  async onClick(ev, w) {
    const t = ev.target.closest('[data-open],[data-cat],[data-go],[data-tag],[data-world],[data-saga],[data-tpl],[data-act],[data-turn],[data-spread],[data-letter]');
    if (!t || t.closest('.eeo-prose a.content-link')) return;
    ev.preventDefault();
    const d = t.dataset; const form = w.querySelector('form.eeo-edit');
    if (d.open) return this.go({ view: 'article', id: d.open });
    if (d.cat) return this.go({ view: 'list', cat: d.cat, tag: null });
    if (d.go === 'secrets') return this.go({ view: 'list', cat: '__secret', tag: null });
    if (d.go) return this.go({ view: d.go, cat: d.go === 'list' ? null : this.S.cat, saga: null, tag: d.go === 'list' ? null : this.S.tag });
    if (d.tag !== undefined) return this.go({ view: 'list', tag: this.S.tag === d.tag ? null : d.tag, cat: null });
    if (d.world) { this.S.world = d.world; return this.render(); }
    if (d.saga) return this.go({ view: 'sagas', saga: d.saga });
    if (d.tpl) { this.S.tpl = d.tpl; this.S.spread = 0; return this.render(); }
    if (d.turn) return this.turn(Number(d.turn));
    if (d.spread) { const k = Number(d.spread); const dir = k > this.S.spread ? 1 : -1; this.S.spread = k; return this.layoutBook(dir); }
    if (d.letter) { w.querySelector(`#eeo-l-${d.letter}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    const j = this.S.id ? game.journal.get(this.S.id) : null;
    switch (d.act) {
      case 'back': return this.goBack();
      case 'new': return newArticle(d.newcat);
      case 'settings': return openSettings();
      case 'edit': return this.go({ view: 'edit', id: this.S.id });
      case 'sheet': return j?.sheet.render(true);
      case 'reveal': {
        const lv = level(j); const next = lv === OWN.NONE ? OWN.LIMITED : lv === OWN.LIMITED ? OWN.OBSERVER : OWN.NONE;
        await j.update({ 'ownership.default': next });
        ui.notifications.info(`${j.name} : ${next === OWN.NONE ? 'secret' : next === OWN.LIMITED ? 'connu de nom par les joueurs' : 'révélé aux joueurs'}.`);
        return;
      }
      case 'cancel-edit': return this.go({ view: 'article', id: this.S.id }, false);
      case 'save': return this.saveEdit(form);
      case 'pick': {
        const inp = form.querySelector('[name="img"]'); const FP = foundry.applications.apps.FilePicker.implementation;
        return new FP({ type: 'image', current: inp.value, callback: p => { inp.value = p; inp.dispatchEvent(new Event('input', { bubbles: true })); } }).render(true);
      }
      case 'reladd': {
        await this.saveEdit(form, true); const a = A(j);
        await j.update({ [`flags.${ID}.rels`]: [...a.rels, { label: 'Lié à', uuid: d.uuid }] }); this._keep = true; return this.render();
      }
      case 'relrm': {
        await this.saveEdit(form, true); const a = A(j);
        await j.update({ [`flags.${ID}.rels`]: a.rels.filter((_, i) => i !== Number(d.i)) }); this._keep = true; return this.render();
      }
      case 'padd': case 'padd-img': {
        await this.saveEdit(form, true);
        const isImg = d.act === 'padd-img';
        const [p] = await j.createEmbeddedDocuments('JournalEntryPage', [isImg ? { name: 'Illustration', type: 'image', src: '' } : { name: 'Nouvelle section', type: 'text', text: { content: '', format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML } }]);
        p?.sheet.render(true); this._keep = true; return this.render();
      }
      case 'pedit': { await this.saveEdit(form, true); j.pages.get(d.p)?.sheet.render(true); return; }
      case 'psecret': {
        const p = j.pages.get(d.p); await this.saveEdit(form, true);
        await p.update({ 'ownership.default': pageSecret(p) ? OWN.INHERIT : OWN.NONE }); this._keep = true; return this.render();
      }
      case 'pup': {
        const ps = j.pages.contents.sort((x, y) => x.sort - y.sort); const i = ps.findIndex(p => p.id === d.p); if (i < 1) return;
        await this.saveEdit(form, true);
        await j.updateEmbeddedDocuments('JournalEntryPage', [{ _id: ps[i].id, sort: ps[i - 1].sort }, { _id: ps[i - 1].id, sort: ps[i].sort }]); this._keep = true; return this.render();
      }
      case 'pdel': {
        const p = j.pages.get(d.p);
        const ok = await foundry.applications.api.DialogV2.confirm({ window: { title: 'Supprimer la section' }, content: `<p>Supprimer définitivement la section « ${esc(p.name)} » ?</p>` });
        if (ok) { await this.saveEdit(form, true); await p.delete(); this._keep = true; this.render(); }
        return;
      }
    }
  }
}

/* ---------- créations et conversions ---------- */
async function newArticle(cat) {
  const ws = worlds();
  const res = await foundry.applications.api.DialogV2.wait({
    window: { title: 'Nouvel article', icon: 'fa-solid fa-feather-pointed' }, classes: ['eeo-dialog'], position: { width: 400 }, rejectClose: false,
    content: `<div class="eeo-form"><label>Titre<input type="text" name="name" autofocus></label>
      <label>Catégorie<select name="cat">${Object.entries(CATS).map(([k, c]) => `<option value="${k}" ${k === cat ? 'selected' : ''}>${c.one}</option>`).join('')}</select></label>
      ${ws.length ? `<label>Monde<select name="world">${ws.map(w => `<option>${esc(w.name)}</option>`).join('')}</select></label>` : ''}
      <p class="eeo-note">L'article est créé secret : les joueurs ne le voient qu'une fois révélé.</p></div>`,
    buttons: [{ action: 'ok', label: 'Créer', icon: 'fa-solid fa-check', default: true, callback: (e, b) => ({ name: b.form.elements.name.value.trim(), cat: b.form.elements.cat.value, world: b.form.elements.world?.value ?? '' }) }, { action: 'cancel', label: 'Annuler' }]
  });
  if (!res?.name) return;
  const folder = await ensureFolder(res.cat);
  const j = await JournalEntry.create({
    name: res.name, folder: folder.id, ownership: { default: OWN.NONE },
    flags: { [ID]: { cat: res.cat, tpl: '', world: res.world, tags: [], summary: '', img: '', imgPos: '50% 30%', fields: {}, rels: [], saga: { name: '', tome: '' }, annee: '' } },
    pages: [{ name: 'Description', type: 'text', text: { content: '', format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML } }]
  });
  Codex.open().go({ view: 'edit', id: j.id });
}
async function convertDialog(j) {
  if (isArt(j)) { Codex.open(j.id); return ui.notifications.info(`${j.name} fait déjà partie de l'encyclopédie.`); }
  const ws = worlds(); const guess = Object.keys(CATS).find(k => norm(j.folder?.name ?? '').includes(norm(CATS[k].label).slice(0, 5))) ?? 'note';
  const img = j.pages.find(p => p.type === 'image')?.src ?? '';
  const res = await foundry.applications.api.DialogV2.wait({
    window: { title: `Convertir · ${j.name}`, icon: 'fa-solid fa-file-import' }, classes: ['eeo-dialog'], position: { width: 400 }, rejectClose: false,
    content: `<div class="eeo-form"><p class="eeo-note">Le journal reste à sa place et garde ses pages : elles deviennent les sections de l'article. Ses droits actuels sont conservés.</p>
      <label>Catégorie<select name="cat">${Object.entries(CATS).map(([k, c]) => `<option value="${k}" ${k === guess ? 'selected' : ''}>${c.one}</option>`).join('')}</select></label>
      ${ws.length ? `<label>Monde<select name="world">${ws.map(w => `<option>${esc(w.name)}</option>`).join('')}</select></label>` : ''}</div>`,
    buttons: [{ action: 'ok', label: 'Convertir', icon: 'fa-solid fa-check', default: true, callback: (e, b) => ({ cat: b.form.elements.cat.value, world: b.form.elements.world?.value ?? '' }) }, { action: 'cancel', label: 'Annuler' }]
  });
  if (!res?.cat) return;
  await j.update({ [`flags.${ID}`]: { cat: res.cat, tpl: '', world: res.world, tags: [], summary: '', img, imgPos: '50% 30%', fields: {}, rels: [], saga: { name: '', tome: '' }, annee: '' } });
  Codex.open().go({ view: 'edit', id: j.id });
}
async function openSettings() {
  const ws = worlds();
  const row = (w = { name: '', color: '#b48a3c' }) => `<div class="eeo-wrow"><input type="text" name="wn" value="${esc(w.name)}" placeholder="Nom du monde"><input type="color" name="wc" value="${esc(w.color)}"><a data-rm><span class="fa-solid fa-xmark"></span></a></div>`;
  let el;
  const res = await foundry.applications.api.DialogV2.wait({
    window: { title: 'Encyclopédie · Réglages', icon: 'fa-solid fa-gear' }, classes: ['eeo-dialog'], position: { width: 420 }, rejectClose: false,
    content: `<div class="eeo-form eeo-set"><h4>Mondes</h4><p class="eeo-note">Avec un seul monde, le filtre par monde n'apparaît pas.</p><div class="eeo-wrows">${ws.map(row).join('')}</div><a class="eeo-btn" data-add><span class="fa-solid fa-plus"></span>Ajouter un monde</a></div>`,
    buttons: [{ action: 'ok', label: 'Enregistrer', icon: 'fa-solid fa-check', default: true, callback: () => 'ok' }, { action: 'cancel', label: 'Annuler' }],
    render: (e, dlg) => {
      el = dlg.element.querySelector('.eeo-set');
      el.addEventListener('click', ev => {
        if (ev.target.closest('[data-add]')) { ev.preventDefault(); el.querySelector('.eeo-wrows').insertAdjacentHTML('beforeend', row()); }
        if (ev.target.closest('[data-rm]')) { ev.preventDefault(); ev.target.closest('.eeo-wrow').remove(); }
      });
    }
  });
  if (res !== 'ok') return;
  const list = [...el.querySelectorAll('.eeo-wrow')].map(r => ({ name: r.querySelector('[name="wn"]').value.trim(), color: r.querySelector('[name="wc"]').value })).filter(w => w.name);
  await game.settings.set(ID, 'worlds', list);
}

/* ---------- branchements ---------- */
Hooks.once('init', () => {
  game.settings.register(ID, 'worlds', { scope: 'world', config: false, type: Array, default: [{ name: 'Éos', color: '#c9a24b' }], onChange: () => Codex.refresh() });
  game.keybindings.register(ID, 'open', { name: 'Ouvrir l\'encyclopédie', editable: [], onDown: () => { Codex.open(); return true; } });
});
Hooks.once('ready', () => {
  game.modules.get(ID).api = { open: id => Codex.open(id), Codex };
});
Hooks.on('renderJournalDirectory', (app, html) => {
  const root = html instanceof HTMLElement ? html : html?.[0] ?? app.element;
  if (!root || root.querySelector('.eeo-open')) return;
  const b = document.createElement('button'); b.type = 'button'; b.className = 'eeo-open';
  b.innerHTML = '<span class="fa-solid fa-book-open"></span> Encyclopédie d\'Éos';
  b.addEventListener('click', ev => { ev.preventDefault(); Codex.open(); });
  (root.querySelector('.directory-header') ?? root).prepend(b);
});
Hooks.on('getJournalEntryContextOptions', (app, opts) => {
  opts.push({ name: 'Ouvrir dans l\'encyclopédie', icon: '<i class="fa-solid fa-book-open"></i>',
    condition: li => { const j = game.journal.get((li instanceof HTMLElement ? li : li?.[0])?.closest('[data-entry-id]')?.dataset.entryId); return isArt(j) || game.user.isGM; },
    callback: li => { const j = game.journal.get((li instanceof HTMLElement ? li : li?.[0])?.closest('[data-entry-id]')?.dataset.entryId); if (!j) return; if (isArt(j)) Codex.open(j.id); else convertDialog(j); } });
});
for (const h of ['createJournalEntry', 'updateJournalEntry', 'deleteJournalEntry', 'createJournalEntryPage', 'updateJournalEntryPage', 'deleteJournalEntryPage']) Hooks.on(h, () => dirty());
